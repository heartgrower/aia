/* If you're feeling fancy you can add interactivity
   to your site with Javascript.
   Note: TypeScript won't work in this file. */

// prints "hi" in the browser's dev tools console
console.log("hi");

const intervalID = setInterval(
  chkL,
  500,
  document.getElementsByTagName("img"),
  "found",
);

function chkL(a, b) {
  if (
    a &&
      window.location.href ==
        "https://matteomusso.com/" ||
    "https://matteomusso.com/services.html" ||
    "https://matteomusso.com/store.html" ||
    "https://matteomusso.com/contact.html" ||
    "https://matteomusso.com/featured.html"
  ) {
    console.log("smaller");
    let w = window.innerWidth;
    let h = window.innerHeight;
    if (w) console.log(w);
    if (h) console.log(h);
    if (w < 738) {
      if (
        window.location.href == "https://matteomusso.com/" ||
        window.location.href == "https://matteomusso.com/services.html"
      ) {
        a[3].style.maxWidth = "50%";
        console.log("A", a[3]);
      }
      // document.getElementsByTagName("a")[4].style.lineHeight =
      //   "4rem !important";
      document.getElementById("hmbt").style.lineHeight = "3rem";
      document.getElementById("abbt").style.lineHeight = "3rem";
      document.getElementById("svbt").style.lineHeight = "3rem";
      document.getElementById("stbt").style.lineHeight = "3rem";
      document.getElementById("ctbt").style.lineHeight = "3rem";
      document.getElementById("ytbt").style.lineHeight = "3rem";
      document.getElementById("azbt").style.lineHeight = "3rem";
      document.getElementById("clbt").style.lineHeight = "3rem";
      // document.getElementById("ytbb").style.lineHeight = "2rem";
    }
    clearInterval(intervalID);
  }
}

//document.getElementsByClassName('illo-container')[0].style.display = "none"
//document.getElementsByClassName('illo-container')[1].style.display = "none"