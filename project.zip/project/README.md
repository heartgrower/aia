# Welcome to Val Town

Val Town is the simplest way to get code running in the cloud.

This is a basic HTML starter template.

1. Click `Remix` on this val to get a copy of it
2. Click `main.tsx` to view the website
3. Saves to any file will instantly deploy

### ← main.tsx

This HTTP server hosts all of the other files in this val.

To view your site in a new tab, click on the `...` menu of `main.tsx` to copy
your live HTTP endpoint.

### ← README.md

That's this file, where you can tell people what your cool website does and how
you built it.

### ← index.html

Where you'll write the content of your website.

### ← style.css

CSS files add styling rules to your content.

### ← script.js

If you're feeling fancy you can add interactivity to your site with JavaScript.

If you want more interactivity, check out this
[React starter](https://www.val.town/x/std/reactHonoStarter).

### ← favicon.svg

The icon that shows up in the brower tab. Tip: AIs are pretty good at writing
SVG favicons.

---

This template was inspired by https://glitch.new/blank.
update servicehtml JS to display none one frame when 2 different buttons clicked